// German
$.L10n._strings.de = {};

// English
$.L10n._strings.en = {};

// Spanish
$.L10n._strings.es = {};

// French
$.L10n._strings.fr = {};

// Italian
$.L10n._strings.it = {};

// Portuguese
$.L10n._strings.pt = {};
